#!/bin/sh
java -jar xiFDR-2.2.1.jar
